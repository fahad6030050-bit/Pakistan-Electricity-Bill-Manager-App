package com.fahadart.pakistanbijlimanager

import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.*
import java.util.Calendar
import java.util.concurrent.TimeUnit

private val Green = Color(0xFF087A45)
private val Pale = Color(0xFFEAF6EF)
private val companies = listOf("K-Electric", "LESCO", "MEPCO", "FESCO", "IESCO", "PESCO", "HESCO", "SEPCO", "QESCO", "GEPCO", "TESCO")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BijliApp() }
    }
}

@Composable
fun BijliApp() {
    var page by remember { mutableStateOf("home") }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Color(0xFF35A66A), background = Color(0xFFF6FAF7))) {
        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = page == "home", onClick = { page = "home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = page == "bill", onClick = { page = "bill" }, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Bill") })
                    NavigationBarItem(selected = page == "units", onClick = { page = "units" }, icon = { Icon(Icons.Default.Bolt, null) }, label = { Text("Units") })
                    NavigationBarItem(selected = page == "reminder", onClick = { page = "reminder" }, icon = { Icon(Icons.Default.Notifications, null) }, label = { Text("Reminder") })
                }
            },
            containerColor = Color(0xFFF6FAF7)
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
                when (page) {
                    "home" -> HomeScreen(onBill = { page = "bill" }, onUnits = { page = "units" }, onReminder = { page = "reminder" })
                    "bill" -> BillScreen()
                    "units" -> UnitsScreen()
                    else -> ReminderScreen()
                }
            }
        }
    }
}

@Composable
fun Header(subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Surface(shape = RoundedCornerShape(16.dp), color = Green, modifier = Modifier.size(48.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Bolt, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Pakistan Bijli Manager", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF123B29))
            Text(subtitle, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun HomeScreen(onBill: () -> Unit, onUnits: () -> Unit, onReminder: () -> Unit) {
    Header("آپ کی بجلی، آپ کے کنٹرول میں")
    Spacer(Modifier.height(22.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(24.dp)) {
        Column(Modifier.padding(20.dp)) {
            Text("ماہانہ بجلی مینجمنٹ", color = Color.White, fontSize = 14.sp)
            Text("آسان، تیز اور منظم", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text("بل دیکھیں، یونٹس سمجھیں اور تاریخ یاد رکھیں۔", color = Color.White.copy(alpha = .9f))
            Spacer(Modifier.height(12.dp))
            Button(onClick = onBill, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Green)) {
                Text("بل چیک کریں")
            }
        }
    }
    Spacer(Modifier.height(18.dp))
    Text("اہم سہولیات", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF173D2B))
    Spacer(Modifier.height(10.dp))
    FeatureCard("بل چیک کریں", "کمپنی منتخب کریں اور ریفرنس نمبر درج کریں", Icons.Default.ReceiptLong, onBill)
    FeatureCard("یونٹ کیلکولیٹر", "یونٹس اور فی یونٹ تخمینی خرچ معلوم کریں", Icons.Default.Bolt, onUnits)
    FeatureCard("بل ریمائنڈر", "بل کی آخری تاریخ کے لیے یاد دہانی لگائیں", Icons.Default.NotificationsActive, onReminder)
    Spacer(Modifier.height(14.dp))
    Text("نوٹ: اصل بل کی رقم متعلقہ بجلی کمپنی کے آفیشل سسٹم سے تصدیق ہوگی۔", color = Color.Gray, fontSize = 12.sp)
}

@Composable
fun FeatureCard(title: String, detail: String, icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit) {
    Card(onClick = click, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Pale, shape = RoundedCornerShape(13.dp), modifier = Modifier.size(44.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Green) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = Color(0xFF183D2D))
                Text(detail, fontSize = 12.sp, color = Color.Gray)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Green)
        }
    }
}

@Composable
fun BillScreen() {
    val context = LocalContext.current
    var company by remember { mutableStateOf(companies[0]) }
    var expanded by remember { mutableStateOf(false) }
    var reference by remember { mutableStateOf("") }
    Header("اپنا بجلی کا بل تلاش کریں")
    Spacer(Modifier.height(20.dp))
    Text("بجلی کی کمپنی", fontWeight = FontWeight.SemiBold)
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(value = company, onValueChange = {}, readOnly = true, label = { Text("کمپنی منتخب کریں") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            companies.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { company = item; expanded = false }) }
        }
    }
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(value = reference, onValueChange = { reference = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Reference Number / Customer ID") }, placeholder = { Text("اپنا ریفرنس نمبر درج کریں") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
    Spacer(Modifier.height(14.dp))
    Button(onClick = {
        val url = if (company == "K-Electric") "https://www.ke.com.pk/" else "https://bill.pitc.com.pk/"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        context.startActivity(intent)
    }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Icon(Icons.Default.OpenInBrowser, null); Spacer(Modifier.width(8.dp)); Text("آفیشل بل پورٹل کھولیں")
    }
    Spacer(Modifier.height(10.dp))
    Text("آپ کا ریفرنس نمبر اس ایپ میں محفوظ یا کسی غیر متعلقہ سرور کو نہیں بھیجا جاتا۔ بل کی آن لائن دستیابی متعلقہ کمپنی کے پورٹل پر منحصر ہے۔", color = Color.Gray, fontSize = 12.sp)
    if (reference.isNotBlank()) Text("درج کردہ نمبر: $reference", color = Green, fontSize = 12.sp)
}

@Composable
fun UnitsScreen() {
    var units by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("40") }
    val u = units.toDoubleOrNull() ?: 0.0
    val r = rate.toDoubleOrNull() ?: 0.0
    Header("یونٹ کیلکولیٹر")
    Spacer(Modifier.height(20.dp))
    OutlinedTextField(value = units, onValueChange = { units = it }, modifier = Modifier.fillMaxWidth(), label = { Text("استعمال شدہ یونٹس") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(value = rate, onValueChange = { rate = it }, modifier = Modifier.fillMaxWidth(), label = { Text("فی یونٹ تخمینی ریٹ (روپے)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
    Spacer(Modifier.height(18.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Pale), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("تخمینی لاگت", color = Green)
            Text("Rs. ${"%,.0f".format(u * r)}", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFF153D2A))
            Text("$units یونٹس × Rs. $rate", color = Color.Gray, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(10.dp))
    Text("یہ صرف سادہ تخمینہ ہے۔ اصل بل میں ٹیکس، فیول ایڈجسٹمنٹ، سلیب اور دیگر چارجز شامل ہو سکتے ہیں۔", color = Color.Gray, fontSize = 12.sp)
}

@Composable
fun ReminderScreen() {
    val context = LocalContext.current
    var days by remember { mutableStateOf("3") }
    var dueDate by remember { mutableStateOf("ہر ماہ کی 15 تاریخ") }
    Header("بل کی یاد دہانی")
    Spacer(Modifier.height(18.dp))
    Text("بل کی آخری تاریخ سے کتنے دن پہلے یاد دلائیں؟")
    OutlinedTextField(value = days, onValueChange = { days = it.filter(Char::isDigit).take(2) }, modifier = Modifier.fillMaxWidth(), label = { Text("دن پہلے") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(value = dueDate, onValueChange = { dueDate = it }, modifier = Modifier.fillMaxWidth(), label = { Text("آخری تاریخ کی تفصیل") })
    Spacer(Modifier.height(16.dp))
    Button(onClick = {
        val delayDays = (days.toLongOrNull() ?: 3L).coerceAtLeast(1L)
        val request = OneTimeWorkRequestBuilder<ReminderWorker>().setInitialDelay(delayDays, TimeUnit.DAYS).build()
        WorkManager.getInstance(context).enqueue(request)
    }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Icon(Icons.Default.NotificationsActive, null); Spacer(Modifier.width(8.dp)); Text("یاد دہانی شیڈول کریں")
    }
    Spacer(Modifier.height(10.dp))
    Text("ابتدائی ورژن میں یہ ایک بار کی یاد دہانی شیڈول کرتا ہے۔ ماہانہ خودکار ریمائنڈر اگلے مرحلے میں شامل کیا جا سکتا ہے۔", color = Color.Gray, fontSize = 12.sp)
}

class ReminderWorker(appContext: android.content.Context, params: WorkerParameters) : Worker(appContext, params) {
    override fun doWork(): Result {
        val manager = applicationContext.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(android.app.NotificationChannel("bill_reminders", "Bill reminders", android.app.NotificationManager.IMPORTANCE_DEFAULT))
        }
        val builder = if (android.os.Build.VERSION.SDK_INT >= 26)
            android.app.Notification.Builder(applicationContext, "bill_reminders")
        else android.app.Notification.Builder(applicationContext)
        val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Pakistan Bijli Manager")
            .setContentText("آپ کے بجلی کے بل کی ادائیگی کی تاریخ قریب ہے۔")
            .build()
        manager.notify(1001, notification)
        return Result.success()
    }
}
